﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using miniKIFIR;
using System.Data;
using System.Security.Cryptography;
using System.Collections.ObjectModel;
using System.Globalization;

namespace miniKIFIR
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Students> studentsList = new ObservableCollection<Students>();

        public MainWindow()
        {
            InitializeComponent();
        }
        private void btnImport_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Adattábla(*.csv)|*.csv;";
            ofd.Title = "Importálás";
            if (ofd.ShowDialog() == true)
            {
                ObservableCollection<Students> studentsList = new ObservableCollection<Students>();
                string[] lines = File.ReadAllLines(ofd.FileName);
                for (int i = 1; i < lines.Length; i++)
                {
                    string line = lines[i];
                    string[] studentArray = line.Split(";");
                    if (studentArray.Length == 7)
                    {
                        Students student = new Students(
                            studentArray[0],
                            studentArray[1],
                            studentArray[2],
                            DateTime.Parse(studentArray[3]),
                            studentArray[4],
                            int.Parse(studentArray[5]),
                            int.Parse(studentArray[6])
                        );
                        studentsList.Add(student);
                    }

                }
                if (dgFelvetelizok.ItemsSource != null)
                {
                    var addResult = MessageBox.Show("A már betöltött adatok mögé szeretné fűzni?", "Importálás", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (addResult == MessageBoxResult.Yes)
                    {
                        ObservableCollection<Students> existingList = (ObservableCollection<Students>)dgFelvetelizok.ItemsSource;

                        foreach (var student in studentsList)
                        {
                            existingList.Add(student);
                        }
                    }
                    else if (addResult == MessageBoxResult.No)
                    {
                        dgFelvetelizok.ItemsSource = studentsList;
                    }
                }
                else
                {
                    dgFelvetelizok.ItemsSource = studentsList;
                }
            }
        }

        private void btnExport_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Adattábla(*.csv)|*.csv;";
            sfd.Title = "Exportálás";
            ObservableCollection<Students> studentsList = (ObservableCollection<Students>)dgFelvetelizok.ItemsSource;
            if (dgFelvetelizok.Items.Count > 0)
            {
                sfd.ShowDialog();
            }
            else
            {
                MessageBox.Show("Nincs betöltött adat!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            if (sfd.FileName != "" && dgFelvetelizok.Items.Count > 0)
            {
                string header = "azonosito;nev;email;szuletesiDatum;ertesitesiCim;matekPont;magyarPont";
                File.WriteAllText(sfd.FileName, header + "\n");
                foreach (Students student in studentsList)
                {
                    string line = $"{student.OM_Azonosito};{student.Neve};{student.Email};{student.SzuletesiDatum};{student.ErtesitesiCime};{student.Matematika};{student.Magyar}";
                    File.AppendAllText(sfd.FileName, line + "\n");
                }
            }
        }

        private void btnTorol_Click(object sender, RoutedEventArgs e)
        {
            if (dgFelvetelizok.SelectedItem != null)
            {
                ObservableCollection<Students> studentsList = (ObservableCollection<Students>)dgFelvetelizok.ItemsSource;
                Students selectedStudent = (Students)dgFelvetelizok.SelectedItem;
                studentsList.Remove(selectedStudent);
                dgFelvetelizok.Items.Refresh();
            }
            else
            {
                MessageBox.Show("Válassz ki egy diákot!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnUj_Click(object sender, RoutedEventArgs e)
        {
                NewStudentWindow newStudent = new NewStudentWindow();
                newStudent.ShowDialog();
                if (newStudent.StudentCreated)
                {
                    newStudent.Close();
                }
        }

        private void windowCloseBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}