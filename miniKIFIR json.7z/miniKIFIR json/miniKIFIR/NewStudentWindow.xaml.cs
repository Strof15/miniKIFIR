﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using System.Collections.ObjectModel;
using System.Text.RegularExpressions;

namespace miniKIFIR
{
    /// <summary>
    /// Interaction logic for NewStudentWindow.xaml
    /// </summary>
    public partial class NewStudentWindow : Window
    {
        public NewStudentWindow()
        {
            InitializeComponent();
        }
        public bool StudentCreated { get; private set; } = false;

        private void btnRogzit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string omAzonositoPattern = @"^\d{11}$";
                string emailPattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";

                if (Regex.IsMatch(txtOmAzonosito.Text, omAzonositoPattern))
                {
                    if (Regex.IsMatch(txtEmail.Text, emailPattern))
                    {
                        string[] nameParts = txtNev.Text.Split(' ');
                        if (nameParts.Length >= 2)
                        {
                            int matekPont, magyarPont;
                            if (int.TryParse(txtMatekPont.Text, out matekPont) && int.TryParse(txtMagyarPont.Text, out magyarPont))
                            {
                                if (matekPont >= 0 && matekPont <= 50 && magyarPont >= 0 && magyarPont <= 50)
                                {
                                    Students student = new Students(
                                        txtOmAzonosito.Text,
                                        txtNev.Text,
                                        txtEmail.Text,
                                        DateTime.Parse(DtSzulIdo.Text),
                                        txtErtesitesiLakcim.Text,
                                        matekPont,
                                        magyarPont
                                    );

                                    MainWindow mainWindow = Application.Current.Windows.OfType<MainWindow>().FirstOrDefault();
                                    if (mainWindow != null)
                                    {
                                        mainWindow.studentsList.Add(student);
                                        mainWindow.dgFelvetelizok.ItemsSource = mainWindow.studentsList;
                                    }

                                    StudentCreated = true;
                                    Close();
                                }
                                else
                                {
                                    MessageBox.Show("A magyar és matematika pontoknak 0 és 50 között kell lennie!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                                }
                            }
                            else
                            {
                                MessageBox.Show("A pontoknak számoknak kell lenniük!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);

                               
                                txtMatekPont.Focus();
                                txtMatekPont.Clear();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Hibás név megadás!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Hibás email cím!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);

                        txtEmail.Focus();
                        txtEmail.Clear();
                    }
                }
                else
                {
                    MessageBox.Show("Hibás OM azonosító! Csak számokat tartalmazhat és 11 karakter hosszú.", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);

                    txtOmAzonosito.Focus();
                    txtOmAzonosito.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void windowCloseBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                e.Handled = true;
                TraversalRequest request = new TraversalRequest(FocusNavigationDirection.Next);
                UIElement elementWithFocus = Keyboard.FocusedElement as UIElement;

                if (elementWithFocus != null)
                {
                    elementWithFocus.MoveFocus(request);
                }
            }
        }
    }
}
