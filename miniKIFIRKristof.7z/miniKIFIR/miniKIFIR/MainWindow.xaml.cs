﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using miniKIFIR;
using System.Data;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace miniKIFIR
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnImport_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog faljBe = new OpenFileDialog();
            faljBe.Filter = "Adattábla(*.csv)|*.csv;";
            faljBe.Title = "Importálás";
            faljBe.ShowDialog();
            if (faljBe.FileName != "")
            {
                string[] lines = File.ReadAllLines(faljBe.FileName);
                List<Students> studentsList = new List<Students>();
                for (int i = 1; i < lines.Length; i++)
                {
                    string line = lines[i];
                    string[] studentArray = line.Split(";");
                    if (studentArray.Length == 7)
                    {
                        Students student = new Students(
                            studentArray[0],
                            studentArray[1],
                            studentArray[2],
                            studentArray[3],
                            studentArray[4],
                            int.Parse(studentArray[5]),
                            int.Parse(studentArray[6])
                        );

                        studentsList.Add(student);
                    }

                }
                dgFelvetelizok.ItemsSource = studentsList;
            }
        }

        private void btnExport_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog mentes = new SaveFileDialog();
            mentes.Filter = "Adattábla(*.csv)|*.csv;";
            mentes.Title = "Exportálás";
            List<Students> studentsList = (List<Students>)dgFelvetelizok.ItemsSource;
            if (dgFelvetelizok.Items.Count > 0)
            {
                mentes.ShowDialog();
            }
            else
            {
                MessageBox.Show("Nincs betöltött adat!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            if (mentes.FileName != "" && dgFelvetelizok.Items.Count > 0)
            {
                string header = "azonosito;nev;email;szuletesiDatum;ertesitesiCim;matekPont;magyarPont";
                File.WriteAllText(mentes.FileName, header + "\n");
                foreach (Students student in studentsList)
                {
                    string line = $"{student.Azonosito};{student.Nev};{student.Email};{student.SzuletesiDatum};{student.ErtesitesiCim};{student.MatekPont};{student.MagyarPont}";
                    File.AppendAllText(mentes.FileName, line + "\n");
                }
            }
        }

        private void btnTorol_Click(object sender, RoutedEventArgs e)
        {
            if (dgFelvetelizok.SelectedItem != null)
            {
                List<Students> studentsList = (List<Students>)dgFelvetelizok.ItemsSource;
                Students selectedStudent = (Students)dgFelvetelizok.SelectedItem;
                studentsList.Remove(selectedStudent);
                dgFelvetelizok.Items.Refresh();
            }
            else
            {
                MessageBox.Show("Válassz ki egy diákot!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            
        }

        private void btnUj_Click(object sender, RoutedEventArgs e)
        {
            NewStudentWindow newstudent = new NewStudentWindow();
            newstudent.ShowDialog();
        }
    }
}
