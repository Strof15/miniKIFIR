﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace miniKIFIR
{
    /// <summary>
    /// Interaction logic for NewStudentWindow.xaml
    /// </summary>
    public partial class NewStudentWindow : Window
    {
        public NewStudentWindow()
        {
            InitializeComponent();
          /*  txtOmAzonosito;
            txtNev;
            txtSzuletesiIdo;
            txtEmail;
            txtMatekPont;
            txtMagyarPont;
            txtErtesitesiLakcim;*/
        }
        
         
         
        private void BtnDiakRogzito(object sender, RoutedEventArgs e)
        {
            List<Students> NewStudentslist = new List<Students>();
            

            if (txtOmAzonosito.Text.Length != 11 && !txtOmAzonosito.Text.All(char.IsDigit))
            {
                MessageBox.Show("hibás megadási mód", "hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                txtOmAzonosito.Focus();
               
            }
            else
            {
                
            }
            if (string.IsNullOrWhiteSpace(txtNev.Text) && txtNev.Text.Length > 40 && !txtNev.Text.All(char.IsLetterOrDigit) && !txtNev.Text.All(char.IsWhiteSpace))
            {
                MessageBox.Show("hibás megadási mód", "hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                txtNev.Focus();
            }
            else
            {

            }
            if (string.IsNullOrWhiteSpace(txtEmail.Text) && !txtEmail.Text.Contains("@"))
            {
                MessageBox.Show("hibás megadási mód", "hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                txtEmail.Focus();
            }
            else
            {

            }
            if (string.IsNullOrWhiteSpace(txtMatekPont.Text) && !txtMatekPont.Text.All(char.IsDigit) && (Convert.ToInt32(txtMatekPont.Text) < 0 || Convert.ToInt32(txtMatekPont.Text) > 50))
            {   

            }
            else
            {

            }
            if (string.IsNullOrWhiteSpace(txtMagyarPont.Text) && !txtMagyarPont.Text.All(char.IsLetter) && (Convert.ToInt32(txtMagyarPont.Text) < 0 || Convert.ToInt32(txtMagyarPont.Text) > 50))
            {

            }
            else
            {

            }
            if (string.IsNullOrWhiteSpace(txtErtesitesiLakcim.Text) && txtErtesitesiLakcim.Text.Length > 100)
            {

            }
            else
            {

            }
           
        
         
        }
    }
}
