﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace miniKIFIR
{
    internal class Students
    {
        string azonosito, nev, email;
        string szuletesiDatum;
        string ertesitesiCim;
        int matekPont, magyarPont;

        public Students(string azonosito, string nev, string email, string szuletesiDatum, string ertesitesiCim, int matekPont, int magyarPont)
        {
            this.azonosito = azonosito;
            this.nev = nev;
            this.email = email;
            this.szuletesiDatum = szuletesiDatum;
            this.ertesitesiCim = ertesitesiCim;
            this.matekPont = matekPont;
            this.magyarPont = magyarPont;
        }

        public string Azonosito { get => azonosito; set => azonosito = value; }
        public string Nev { get => nev; set => nev = value; }
        public string Email { get => email; set => email = value; }
        public string SzuletesiDatum { get => szuletesiDatum; set => szuletesiDatum = value; }
        public string ErtesitesiCim { get => ertesitesiCim; set => ertesitesiCim = value; }
        public int MatekPont { get => matekPont; set => matekPont = value; }
        public int MagyarPont { get => magyarPont; set => magyarPont = value; }
    }
}
